#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible.module_utils.basic import AnsibleModule
import requests
import json
import hashlib
import time

DOCUMENTATION = r'''
---
module: get_qingteng_host_status
short_description: 查询qingteng主机在线和代理状态
description:
- 通过qingteng系统API批量获取主机的在线状态及代理状态
- 支持同时查询多个IP和主机名的混合查询
- 需先通过认证接口获取JWT令牌和签名密钥
version_added: "1.0.0"
author: "amber.wu@vertice.cn"
requirements:
- python >= 3.6
- requests >= 2.25.1
options:
  api_url:
    description: qingteng系统API入口地址
    required: true
    type: str
    example: "https://api.qingteng.example.com"
  username:
    description: API认证用户名
    required: true
    type: str
  password:
    description: API认证密码（自动隐藏输出）
    required: true
    type: str
    no_log: true
  ip_addresses:
    description: 目标IP地址列表
    required: true
    type: list
    elements: str
    aliases: [ ips ]
  hostnames:
    description: 对应主机名列表（必须与ip_addresses数量一致）
    required: true
    type: list
    elements: str
notes:
- 生产环境建议配置 validate_certs=yes 并配置可信CA证书
- 当agent_status返回3（删除中）时需联系基础设施团队处理
'''

EXAMPLES = r'''
- name: 获取单台主机状态
  verticetech.qingteng_host.get_qingteng_host_status:
    api_url: "https://api.qingteng-prod.com"
    username: "api_operator"
    password: "securePassword123!"
    ip_addresses: ["10.10.1.100"]
    hostnames: ["web-server-01"]
  register: host_status

- name: 检查集群主机状态
  verticetech.qingteng_host.get_qingteng_host_status:
    api_url: "{{ qingteng_api }}"
    username: "{{ api_user }}"
    password: "{{ api_pass }}"
    ip_addresses:
      - "10.10.2.101"
      - "10.10.2.102"
    hostnames:
      - "db-primary"
      - "db-replica"
'''

RETURN = r'''
changed:
  description: 永远返回False，此模块仅用于查询
  returned: always
  type: bool
  sample: false
hosts_info:
  description: 主机状态详情列表
  type: list
  elements: dict
  contains:
    ip_address:
      description: 主机IP地址
      type: str
      sample: "10.10.1.100"
    hostname:
      description: 系统主机名
      type: str
      sample: "web-server-01"
    online_status:
      description: 在线状态
      type: str
      choices: [ 在线, 离线, 未知 ]
    agent_status:
      description: 代理运行状态
      type: str
      choices: [ 在线, 离线, 停用, 删除中, 未知 ]
'''


def get_auth(module, api_url, username, password):
    """获取鉴权信息"""
    auth_url = "{0}/v1/api/auth".format(api_url)
    try:
        response = requests.post(
            auth_url,
            headers={'Content-Type': 'application/json'},
            data=json.dumps({"username": username, "password": password}),
            timeout=30,
            verify=False
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        module.fail_json(msg=" 认证请求失败: {0}".format(str(e)))


def make_sign(com_id, params, timestamp, sign_key):
    """生成签名"""
    sign_str = "{0}{1}{2}{3}".format(com_id, params, timestamp, sign_key)
    return hashlib.sha1(sign_str.encode()).hexdigest()


def query_host_status(module, api_url, ip, hostname, com_id, jwt, sign_key):
    """查询主机状态"""
    params = "hostname{0}ip{1}".format(hostname, ip)
    timestamp = str(int(time.time() * 1000))
    sign = make_sign(com_id, params, timestamp, sign_key)

    request_url = "{0}/external/api/assets/host/linux?ip={1}&hostname={2}".format(
        api_url, ip, hostname)
    try:
        response = requests.get(
            request_url,
            headers={
                "Content-Type": "application/json",
                "comId": com_id,
                "timestamp": timestamp,
                "sign": sign,
                "Authorization": "Bearer {0}".format(jwt)
            },
            timeout=30,
            verify=False
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        module.fail_json(msg=" 主机查询请求失败: {0}".format(str(e)))


def main():
    module_args = dict(
        api_url=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        ip_addresses=dict(
            type='list',
            elements='str',
            required=True,
            aliases=['ips']
        ),
        hostnames=dict(
            type='list',
            elements='str',
            required=True
        )
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
        required_together=[
            ('ip_addresses', 'hostnames'),
        ]
    )

    if len(module.params['ip_addresses']) != len(module.params['hostnames']):
        module.fail_json(msg="IP 地址列表与主机名列表数量不一致")

    auth_data = get_auth(module, module.params['api_url'],
                         module.params['username'], module.params['password'])
    if not auth_data.get('success'):
        module.fail_json(
            msg=" 认证失败: {0}".format(
                auth_data.get(
                    'message',
                    '未知错误')))

    result = dict(
        changed=False,
        hosts_info=[]
    )

    com_id = auth_data['data']['comId']
    jwt = auth_data['data']['jwt']
    sign_key = auth_data['data']['signKey']

    for ip, hostname in zip(
            module.params['ip_addresses'], module.params['hostnames']):
        host_info = {
            'ip_address': ip,
            'hostname': hostname,
            'online_status': '未知',
            'agent_status': '未知'
        }

        response = query_host_status(
            module,
            module.params['api_url'],
            ip,
            hostname,
            com_id,
            jwt,
            sign_key
        )

        if response and response.get('total', 0) > 0:
            row = response['rows'][0]
            host_info['online_status'] = '在线' if row.get(
                'onlineStatus') == 1 else '离线'
            host_info['agent_status'] = {
                0: '在线',
                1: '离线',
                2: '停用',
                3: '删除中'
            }.get(row.get('agentStatus', -1), '未知')

        result['hosts_info'].append(host_info)

    module.exit_json(**result)


if __name__ == '__main__':
    main()
