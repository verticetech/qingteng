from ansible.module_utils.basic import AnsibleModule
import requests
import json
import hashlib
import time

def get_auth(api_url, username, password):
    """获取鉴权信息"""
    auth_url = f"{api_url}/v1/api/auth"
    response = requests.post(auth_url, headers={'content-type': 'application/json'},
                             data=json.dumps({"username": username, "password": password}), verify=False)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def make_sign(com_id, params, timestamp, sign_key):
    """生成签名"""
    sign_str = f"{com_id}{params}{timestamp}{sign_key}"
    sign = hashlib.sha1(sign_str.encode()).hexdigest()
    return sign

def query_host_status(api_url, ip, hostname, com_id, jwt, sign_key):
    """查询主机状态"""
    params = f"hostname{hostname}ip{ip}"
    timestamp = str(int(time.time() * 1000))
    sign = make_sign(com_id, params, timestamp, sign_key)

    request_url = f"{api_url}/external/api/assets/host/linux?ip={ip}&hostname={hostname}"
    headers = {
        "content-type": "application/json",
        "comId": com_id,
        "timestamp": timestamp,
        "sign": sign,
        "Authorization": f"Bearer {jwt}"
    }
    response = requests.get(request_url, headers=headers, verify=False)

    if response.status_code == 200:
        return response.json()
    else:
        return None

def main():
    module_args = dict(
        api_url=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        ip_addresses=dict(type='list', elements='str', required=True),
        hostnames=dict(type='list', elements='str', required=True)
    )

    result = dict(
        changed=False,
        hosts_info=[]
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    api_url = module.params['api_url']
    username = module.params['username']
    password = module.params['password']
    ip_addresses = module.params['ip_addresses']
    hostnames = module.params['hostnames']

    if len(ip_addresses) != len(hostnames):
        module.fail_json(msg="The number of IP addresses must match the number of hostnames", **result)

    auth_data = get_auth(api_url, username, password)
    if not auth_data or not auth_data.get('success'):
        module.fail_json(msg="Failed to authenticate with QingTing API", **result)

    com_id = auth_data['data']['comId']
    jwt = auth_data['data']['jwt']
    sign_key = auth_data['data']['signKey']

    for ip, hostname in zip(ip_addresses, hostnames):
        host_info = {
            'ip_address': ip,
            'hostname': hostname,
            'online_status': '未知',
            'agent_status': '未知'
        }

        response = query_host_status(api_url, ip, hostname, com_id, jwt, sign_key)
        if response and response.get('total') > 0:
            row = response['rows'][0]
            online_status = row.get('onlineStatus')
            agent_status = row.get('agentStatus')

            host_info['online_status'] = '在线' if online_status == 1 else '离线'
            host_info['agent_status'] = {
                0: '在线',
                1: '离线',
                2: '停用',
                3: '删除中'
            }.get(agent_status, '未知')

        result['hosts_info'].append(host_info)

    # 移除显式的 changed=False 参数，只使用 **result 来传递结果。
    module.exit_json(**result)

if __name__ == '__main__':
    main()
